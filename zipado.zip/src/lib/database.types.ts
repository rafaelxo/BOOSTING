export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  graphql_public: {
    Tables: {
      [_ in never]: never
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      graphql: {
        Args: {
          extensions?: Json
          operationName?: string
          query?: string
          variables?: Json
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          actor_id: string
          actor_role: Database["public"]["Enums"]["user_role"]
          created_at: string
          diff: Json | null
          entity_id: string
          entity_type: string
          id: string
          ip_address: unknown
        }
        Insert: {
          action: string
          actor_id: string
          actor_role: Database["public"]["Enums"]["user_role"]
          created_at?: string
          diff?: Json | null
          entity_id: string
          entity_type: string
          id?: string
          ip_address?: unknown
        }
        Update: {
          action?: string
          actor_id?: string
          actor_role?: Database["public"]["Enums"]["user_role"]
          created_at?: string
          diff?: Json | null
          entity_id?: string
          entity_type?: string
          id?: string
          ip_address?: unknown
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      booster_ledger_entries: {
        Row: {
          actor_id: string | null
          actor_role: Database["public"]["Enums"]["user_role"] | null
          amount: number
          booster_id: string
          correlation_id: string
          created_at: string
          description: string | null
          entry_type: Database["public"]["Enums"]["ledger_entry_type"]
          id: string
          metadata: Json
          order_id: string | null
          payout_request_id: string | null
        }
        Insert: {
          actor_id?: string | null
          actor_role?: Database["public"]["Enums"]["user_role"] | null
          amount: number
          booster_id: string
          correlation_id?: string
          created_at?: string
          description?: string | null
          entry_type: Database["public"]["Enums"]["ledger_entry_type"]
          id?: string
          metadata?: Json
          order_id?: string | null
          payout_request_id?: string | null
        }
        Update: {
          actor_id?: string | null
          actor_role?: Database["public"]["Enums"]["user_role"] | null
          amount?: number
          booster_id?: string
          correlation_id?: string
          created_at?: string
          description?: string | null
          entry_type?: Database["public"]["Enums"]["ledger_entry_type"]
          id?: string
          metadata?: Json
          order_id?: string | null
          payout_request_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "booster_ledger_entries_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booster_ledger_entries_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booster_ledger_entries_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booster_ledger_entries_payout_request_id_fkey"
            columns: ["payout_request_id"]
            isOneToOne: false
            referencedRelation: "payout_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      booster_order_events: {
        Row: {
          created_at: string
          id: number
          order_id: string
        }
        Insert: {
          created_at?: string
          id?: never
          order_id: string
        }
        Update: {
          created_at?: string
          id?: never
          order_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "booster_order_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booster_order_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      booster_performance_segments: {
        Row: {
          adjusted_rating: number
          adjusted_win_rate: number
          average_kda: number | null
          average_rating: number | null
          booster_id: string
          calculated_at: string
          id: string
          last_match_at: string | null
          losses: number
          normalized_kda: number
          performance_score: number
          rank_bucket: string
          review_count: number
          score_version: string
          service_type: string
          total_matches: number
          updated_at: string
          wins: number
        }
        Insert: {
          adjusted_rating?: number
          adjusted_win_rate?: number
          average_kda?: number | null
          average_rating?: number | null
          booster_id: string
          calculated_at?: string
          id?: string
          last_match_at?: string | null
          losses?: number
          normalized_kda?: number
          performance_score?: number
          rank_bucket?: string
          review_count?: number
          score_version?: string
          service_type?: string
          total_matches?: number
          updated_at?: string
          wins?: number
        }
        Update: {
          adjusted_rating?: number
          adjusted_win_rate?: number
          average_kda?: number | null
          average_rating?: number | null
          booster_id?: string
          calculated_at?: string
          id?: string
          last_match_at?: string | null
          losses?: number
          normalized_kda?: number
          performance_score?: number
          rank_bucket?: string
          review_count?: number
          score_version?: string
          service_type?: string
          total_matches?: number
          updated_at?: string
          wins?: number
        }
        Relationships: [
          {
            foreignKeyName: "booster_performance_segments_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "booster_profiles"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "booster_performance_segments_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "public_booster_profiles"
            referencedColumns: ["user_id"]
          },
        ]
      }
      booster_profiles: {
        Row: {
          available_days: string[] | null
          bio: string | null
          cpf: string | null
          created_at: string
          current_rank: Json | null
          display_name: string
          display_name_changed_at: string | null
          email: string | null
          full_name: string | null
          games: string[]
          hours_per_day_max: number | null
          hours_per_day_min: number | null
          id: string
          is_top3: boolean
          lanes: string[] | null
          last_active_at: string | null
          opgg_link: string | null
          peak_rank: Json | null
          queue_preferences: string[]
          rating: number
          rating_count: number
          region_preferences: string[]
          specialties: string[] | null
          status: Database["public"]["Enums"]["booster_status"]
          total_completed: number
          total_earnings: number
          updated_at: string
          user_id: string
          verified_at: string | null
        }
        Insert: {
          available_days?: string[] | null
          bio?: string | null
          cpf?: string | null
          created_at?: string
          current_rank?: Json | null
          display_name: string
          display_name_changed_at?: string | null
          email?: string | null
          full_name?: string | null
          games?: string[]
          hours_per_day_max?: number | null
          hours_per_day_min?: number | null
          id?: string
          is_top3?: boolean
          lanes?: string[] | null
          last_active_at?: string | null
          opgg_link?: string | null
          peak_rank?: Json | null
          queue_preferences?: string[]
          rating?: number
          rating_count?: number
          region_preferences?: string[]
          specialties?: string[] | null
          status?: Database["public"]["Enums"]["booster_status"]
          total_completed?: number
          total_earnings?: number
          updated_at?: string
          user_id: string
          verified_at?: string | null
        }
        Update: {
          available_days?: string[] | null
          bio?: string | null
          cpf?: string | null
          created_at?: string
          current_rank?: Json | null
          display_name?: string
          display_name_changed_at?: string | null
          email?: string | null
          full_name?: string | null
          games?: string[]
          hours_per_day_max?: number | null
          hours_per_day_min?: number | null
          id?: string
          is_top3?: boolean
          lanes?: string[] | null
          last_active_at?: string | null
          opgg_link?: string | null
          peak_rank?: Json | null
          queue_preferences?: string[]
          rating?: number
          rating_count?: number
          region_preferences?: string[]
          specialties?: string[] | null
          status?: Database["public"]["Enums"]["booster_status"]
          total_completed?: number
          total_earnings?: number
          updated_at?: string
          user_id?: string
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "booster_profiles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      booster_services: {
        Row: {
          availability_note: string | null
          booster_id: string
          created_at: string | null
          description: string
          id: string
          is_active: boolean
          lanes: string[] | null
          price: number
          requirements: string | null
          rules: string | null
          service_type: string | null
          specialties: string[] | null
          tempo: string
          title: string
          unit: string
          updated_at: string
        }
        Insert: {
          availability_note?: string | null
          booster_id: string
          created_at?: string | null
          description: string
          id?: string
          is_active?: boolean
          lanes?: string[] | null
          price?: number
          requirements?: string | null
          rules?: string | null
          service_type?: string | null
          specialties?: string[] | null
          tempo: string
          title: string
          unit?: string
          updated_at?: string
        }
        Update: {
          availability_note?: string | null
          booster_id?: string
          created_at?: string | null
          description?: string
          id?: string
          is_active?: boolean
          lanes?: string[] | null
          price?: number
          requirements?: string | null
          rules?: string | null
          service_type?: string | null
          specialties?: string[] | null
          tempo?: string
          title?: string
          unit?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "booster_services_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_profiles: {
        Row: {
          country: string | null
          created_at: string
          display_name: string | null
          id: string
          preferred_language: string | null
          total_orders: number
          total_spent: number
          user_id: string
        }
        Insert: {
          country?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          preferred_language?: string | null
          total_orders?: number
          total_spent?: number
          user_id: string
        }
        Update: {
          country?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          preferred_language?: string | null
          total_orders?: number
          total_spent?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_profiles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      duo_accounts: {
        Row: {
          created_at: string
          created_by: string | null
          current_rank: Json | null
          encrypted_credentials: string | null
          game_id: string
          id: string
          is_active: boolean
          label: string
          notes: string | null
          reserved_at: string | null
          reserved_by: string | null
          reserved_order_id: string | null
          riot_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          current_rank?: Json | null
          encrypted_credentials?: string | null
          game_id?: string
          id?: string
          is_active?: boolean
          label: string
          notes?: string | null
          reserved_at?: string | null
          reserved_by?: string | null
          reserved_order_id?: string | null
          riot_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          current_rank?: Json | null
          encrypted_credentials?: string | null
          game_id?: string
          id?: string
          is_active?: boolean
          label?: string
          notes?: string | null
          reserved_at?: string | null
          reserved_by?: string | null
          reserved_order_id?: string | null
          riot_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "duo_accounts_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "duo_accounts_reserved_by_fkey"
            columns: ["reserved_by"]
            isOneToOne: false
            referencedRelation: "booster_profiles"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "duo_accounts_reserved_by_fkey"
            columns: ["reserved_by"]
            isOneToOne: false
            referencedRelation: "public_booster_profiles"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "duo_accounts_reserved_order_id_fkey"
            columns: ["reserved_order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "duo_accounts_reserved_order_id_fkey"
            columns: ["reserved_order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      edge_rate_limits: {
        Row: {
          request_count: number
          scope: string
          subject: string
          window_started_at: string
        }
        Insert: {
          request_count: number
          scope: string
          subject: string
          window_started_at: string
        }
        Update: {
          request_count?: number
          scope?: string
          subject?: string
          window_started_at?: string
        }
        Relationships: []
      }
      games: {
        Row: {
          icon_url: string | null
          id: string
          is_active: boolean
          name: string
          slug: string
          sort_order: number
        }
        Insert: {
          icon_url?: string | null
          id?: string
          is_active?: boolean
          name: string
          slug: string
          sort_order?: number
        }
        Update: {
          icon_url?: string | null
          id?: string
          is_active?: boolean
          name?: string
          slug?: string
          sort_order?: number
        }
        Relationships: []
      }
      master_plus_pricing: {
        Row: {
          current_tier: string
          id: string
          pdl_from: number
          price: number | null
          queue_type: Database["public"]["Enums"]["queue_type"]
          target_tier: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          current_tier: string
          id?: string
          pdl_from: number
          price?: number | null
          queue_type: Database["public"]["Enums"]["queue_type"]
          target_tier: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          current_tier?: string
          id?: string
          pdl_from?: number
          price?: number | null
          queue_type?: Database["public"]["Enums"]["queue_type"]
          target_tier?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          data: Json
          id: string
          is_read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          data?: Json
          id?: string
          is_read?: boolean
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          data?: Json
          id?: string
          is_read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      order_drop_requests: {
        Row: {
          admin_id: string | null
          admin_note: string | null
          booster_id: string
          created_at: string
          id: string
          losses_at_request: number
          order_id: string
          penalty_amount: number
          penalty_pct: number
          reason: string
          resolved_at: string | null
          status: string
          wins_at_request: number
        }
        Insert: {
          admin_id?: string | null
          admin_note?: string | null
          booster_id: string
          created_at?: string
          id?: string
          losses_at_request?: number
          order_id: string
          penalty_amount?: number
          penalty_pct?: number
          reason: string
          resolved_at?: string | null
          status?: string
          wins_at_request?: number
        }
        Update: {
          admin_id?: string | null
          admin_note?: string | null
          booster_id?: string
          created_at?: string
          id?: string
          losses_at_request?: number
          order_id?: string
          penalty_amount?: number
          penalty_pct?: number
          reason?: string
          resolved_at?: string | null
          status?: string
          wins_at_request?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_drop_requests_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_drop_requests_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_drop_requests_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_drop_requests_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_matches: {
        Row: {
          assists: number
          champion: string | null
          created_at: string
          deaths: number
          duration_seconds: number | null
          external_match_id: string
          id: string
          kills: number
          order_id: string
          played_at: string
          queue_id: number | null
          result: string
        }
        Insert: {
          assists?: number
          champion?: string | null
          created_at?: string
          deaths?: number
          duration_seconds?: number | null
          external_match_id: string
          id?: string
          kills?: number
          order_id: string
          played_at: string
          queue_id?: number | null
          result: string
        }
        Update: {
          assists?: number
          champion?: string | null
          created_at?: string
          deaths?: number
          duration_seconds?: number | null
          external_match_id?: string
          id?: string
          kills?: number
          order_id?: string
          played_at?: string
          queue_id?: number | null
          result?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_matches_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_matches_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_messages: {
        Row: {
          attachment_url: string | null
          content: string
          created_at: string
          id: string
          is_read: boolean
          order_id: string
          sender_id: string
          sender_role: Database["public"]["Enums"]["user_role"]
        }
        Insert: {
          attachment_url?: string | null
          content: string
          created_at?: string
          id?: string
          is_read?: boolean
          order_id: string
          sender_id: string
          sender_role: Database["public"]["Enums"]["user_role"]
        }
        Update: {
          attachment_url?: string | null
          content?: string
          created_at?: string
          id?: string
          is_read?: boolean
          order_id?: string
          sender_id?: string
          sender_role?: Database["public"]["Enums"]["user_role"]
        }
        Relationships: [
          {
            foreignKeyName: "order_messages_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_messages_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_messages_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      order_rank_verifications: {
        Row: {
          created_at: string
          error_reason: string | null
          fetched_division: string | null
          fetched_lp: number | null
          fetched_tier: string | null
          id: string
          order_id: string
          passed: boolean
          requested_by: string
          riot_id_checked: string
          target_division: string | null
          target_tier: string
        }
        Insert: {
          created_at?: string
          error_reason?: string | null
          fetched_division?: string | null
          fetched_lp?: number | null
          fetched_tier?: string | null
          id?: string
          order_id: string
          passed: boolean
          requested_by: string
          riot_id_checked: string
          target_division?: string | null
          target_tier: string
        }
        Update: {
          created_at?: string
          error_reason?: string | null
          fetched_division?: string | null
          fetched_lp?: number | null
          fetched_tier?: string | null
          id?: string
          order_id?: string
          passed?: boolean
          requested_by?: string
          riot_id_checked?: string
          target_division?: string | null
          target_tier?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_rank_verifications_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_rank_verifications_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_rank_verifications_requested_by_fkey"
            columns: ["requested_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      order_status_events: {
        Row: {
          created_at: string
          id: number
          order_id: string
          status: Database["public"]["Enums"]["order_status"]
        }
        Insert: {
          created_at?: string
          id?: never
          order_id: string
          status: Database["public"]["Enums"]["order_status"]
        }
        Update: {
          created_at?: string
          id?: never
          order_id?: string
          status?: Database["public"]["Enums"]["order_status"]
        }
        Relationships: [
          {
            foreignKeyName: "order_status_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_status_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_status_history: {
        Row: {
          changed_by: string
          created_at: string
          from_status: Database["public"]["Enums"]["order_status"] | null
          id: string
          order_id: string
          reason: string | null
          to_status: Database["public"]["Enums"]["order_status"]
        }
        Insert: {
          changed_by: string
          created_at?: string
          from_status?: Database["public"]["Enums"]["order_status"] | null
          id?: string
          order_id: string
          reason?: string | null
          to_status: Database["public"]["Enums"]["order_status"]
        }
        Update: {
          changed_by?: string
          created_at?: string
          from_status?: Database["public"]["Enums"]["order_status"] | null
          id?: string
          order_id?: string
          reason?: string | null
          to_status?: Database["public"]["Enums"]["order_status"]
        }
        Relationships: [
          {
            foreignKeyName: "order_status_history_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_status_history_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_status_history_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_support_escalations: {
        Row: {
          customer_id: string
          deadline_at: string
          delay_minutes: number
          id: string
          order_id: string
          requested_at: string
          resolved_at: string | null
          resolved_by: string | null
          status: string
        }
        Insert: {
          customer_id: string
          deadline_at: string
          delay_minutes: number
          id?: string
          order_id: string
          requested_at?: string
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
        }
        Update: {
          customer_id?: string
          deadline_at?: string
          delay_minutes?: number
          id?: string
          order_id?: string
          requested_at?: string
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_support_escalations_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_support_escalations_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_support_escalations_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_support_escalations_resolved_by_fkey"
            columns: ["resolved_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          assigned_booster_id: string | null
          avg_pdl_gain: number | null
          avg_pdl_loss: number | null
          base_price: number
          boost_mode: string
          booster_notes: string | null
          booster_service_id: string | null
          chat_locked: boolean
          chat_locked_at: string | null
          chat_locked_by: string | null
          completed_at: string | null
          created_at: string
          credential_expires_at: string | null
          credentials_set: boolean
          current_pdl: number | null
          current_rank: Json
          customer_id: string
          customer_notes: string | null
          discord_voice_channel_id: string | null
          estimated_hours: number | null
          exclusive_until: string | null
          extras: Json
          extras_price: number
          game_credentials: string | null
          game_id: string
          id: string
          idempotency_key: string
          last_match_synced_at: string | null
          losses_played: number
          match_sync_started_at: string | null
          md5_matches_remaining: number | null
          mp_payment_id: string | null
          payment_status: Database["public"]["Enums"]["payment_status"] | null
          pdl_bracket: string | null
          preferred_booster_id: string | null
          pricing_version: string
          queue_type: Database["public"]["Enums"]["queue_type"]
          riot_id: string | null
          server: string
          service_id: string
          service_type: Database["public"]["Enums"]["service_type"]
          sessions_purchased: number | null
          status: Database["public"]["Enums"]["order_status"]
          target_rank: Json | null
          total_price: number
          updated_at: string
          used_exclusive_slot: boolean
          win_package: number | null
          wins_played: number
          wins_purchased: number | null
        }
        Insert: {
          assigned_booster_id?: string | null
          avg_pdl_gain?: number | null
          avg_pdl_loss?: number | null
          base_price: number
          boost_mode?: string
          booster_notes?: string | null
          booster_service_id?: string | null
          chat_locked?: boolean
          chat_locked_at?: string | null
          chat_locked_by?: string | null
          completed_at?: string | null
          created_at?: string
          credential_expires_at?: string | null
          credentials_set?: boolean
          current_pdl?: number | null
          current_rank: Json
          customer_id: string
          customer_notes?: string | null
          discord_voice_channel_id?: string | null
          estimated_hours?: number | null
          exclusive_until?: string | null
          extras?: Json
          extras_price?: number
          game_credentials?: string | null
          game_id: string
          id?: string
          idempotency_key?: string
          last_match_synced_at?: string | null
          losses_played?: number
          match_sync_started_at?: string | null
          md5_matches_remaining?: number | null
          mp_payment_id?: string | null
          payment_status?: Database["public"]["Enums"]["payment_status"] | null
          pdl_bracket?: string | null
          preferred_booster_id?: string | null
          pricing_version?: string
          queue_type?: Database["public"]["Enums"]["queue_type"]
          riot_id?: string | null
          server: string
          service_id: string
          service_type: Database["public"]["Enums"]["service_type"]
          sessions_purchased?: number | null
          status?: Database["public"]["Enums"]["order_status"]
          target_rank?: Json | null
          total_price: number
          updated_at?: string
          used_exclusive_slot?: boolean
          win_package?: number | null
          wins_played?: number
          wins_purchased?: number | null
        }
        Update: {
          assigned_booster_id?: string | null
          avg_pdl_gain?: number | null
          avg_pdl_loss?: number | null
          base_price?: number
          boost_mode?: string
          booster_notes?: string | null
          booster_service_id?: string | null
          chat_locked?: boolean
          chat_locked_at?: string | null
          chat_locked_by?: string | null
          completed_at?: string | null
          created_at?: string
          credential_expires_at?: string | null
          credentials_set?: boolean
          current_pdl?: number | null
          current_rank?: Json
          customer_id?: string
          customer_notes?: string | null
          discord_voice_channel_id?: string | null
          estimated_hours?: number | null
          exclusive_until?: string | null
          extras?: Json
          extras_price?: number
          game_credentials?: string | null
          game_id?: string
          id?: string
          idempotency_key?: string
          last_match_synced_at?: string | null
          losses_played?: number
          match_sync_started_at?: string | null
          md5_matches_remaining?: number | null
          mp_payment_id?: string | null
          payment_status?: Database["public"]["Enums"]["payment_status"] | null
          pdl_bracket?: string | null
          preferred_booster_id?: string | null
          pricing_version?: string
          queue_type?: Database["public"]["Enums"]["queue_type"]
          riot_id?: string | null
          server?: string
          service_id?: string
          service_type?: Database["public"]["Enums"]["service_type"]
          sessions_purchased?: number | null
          status?: Database["public"]["Enums"]["order_status"]
          target_rank?: Json | null
          total_price?: number
          updated_at?: string
          used_exclusive_slot?: boolean
          win_package?: number | null
          wins_played?: number
          wins_purchased?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "orders_assigned_booster_id_fkey"
            columns: ["assigned_booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_booster_service_id_fkey"
            columns: ["booster_service_id"]
            isOneToOne: false
            referencedRelation: "booster_services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_chat_locked_by_fkey"
            columns: ["chat_locked_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_preferred_booster_id_fkey"
            columns: ["preferred_booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          created_at: string
          currency: string
          customer_id: string
          id: string
          metadata: Json
          mp_payment_id: string
          order_id: string
          payment_method_type: string | null
          refunded_amount: number
          status: Database["public"]["Enums"]["payment_status"]
          updated_at: string
          webhook_event_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          customer_id: string
          id?: string
          metadata?: Json
          mp_payment_id: string
          order_id: string
          payment_method_type?: string | null
          refunded_amount?: number
          status?: Database["public"]["Enums"]["payment_status"]
          updated_at?: string
          webhook_event_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          customer_id?: string
          id?: string
          metadata?: Json
          mp_payment_id?: string
          order_id?: string
          payment_method_type?: string | null
          refunded_amount?: number
          status?: Database["public"]["Enums"]["payment_status"]
          updated_at?: string
          webhook_event_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payments_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_records: {
        Row: {
          booster_id: string
          commission_amount: number
          commission_rate: number
          created_at: string
          gross_amount: number
          id: string
          net_amount: number
          order_id: string
          paid_at: string | null
          status: Database["public"]["Enums"]["payout_status"]
        }
        Insert: {
          booster_id: string
          commission_amount: number
          commission_rate?: number
          created_at?: string
          gross_amount: number
          id?: string
          net_amount: number
          order_id: string
          paid_at?: string | null
          status?: Database["public"]["Enums"]["payout_status"]
        }
        Update: {
          booster_id?: string
          commission_amount?: number
          commission_rate?: number
          created_at?: string
          gross_amount?: number
          id?: string
          net_amount?: number
          order_id?: string
          paid_at?: string | null
          status?: Database["public"]["Enums"]["payout_status"]
        }
        Relationships: [
          {
            foreignKeyName: "payout_records_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_records_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_records_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_requests: {
        Row: {
          admin_note: string | null
          amount: number
          booster_cpf_snapshot: string | null
          booster_id: string
          booster_legal_name_snapshot: string | null
          created_at: string
          id: string
          paid_at: string | null
          paid_by: string | null
          proof_url: string | null
          rejection_reason: string | null
          requested_at: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["payout_request_status"]
          updated_at: string
        }
        Insert: {
          admin_note?: string | null
          amount: number
          booster_cpf_snapshot?: string | null
          booster_id: string
          booster_legal_name_snapshot?: string | null
          created_at?: string
          id?: string
          paid_at?: string | null
          paid_by?: string | null
          proof_url?: string | null
          rejection_reason?: string | null
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["payout_request_status"]
          updated_at?: string
        }
        Update: {
          admin_note?: string | null
          amount?: number
          booster_cpf_snapshot?: string | null
          booster_id?: string
          booster_legal_name_snapshot?: string | null
          created_at?: string
          id?: string
          paid_at?: string | null
          paid_by?: string | null
          proof_url?: string | null
          rejection_reason?: string | null
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["payout_request_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payout_requests_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_requests_paid_by_fkey"
            columns: ["paid_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          discord_id: string | null
          email: string
          id: string
          legal_version: string | null
          privacy_accepted_at: string | null
          role: Database["public"]["Enums"]["user_role"]
          terms_accepted_at: string | null
          updated_at: string
          username: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          discord_id?: string | null
          email: string
          id: string
          legal_version?: string | null
          privacy_accepted_at?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          terms_accepted_at?: string | null
          updated_at?: string
          username: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          discord_id?: string | null
          email?: string
          id?: string
          legal_version?: string | null
          privacy_accepted_at?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          terms_accepted_at?: string | null
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      refunds: {
        Row: {
          amount: number
          created_at: string
          id: string
          initiated_by: string
          mp_refund_id: string
          order_id: string
          payment_id: string
          reason: string
          status: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          initiated_by: string
          mp_refund_id: string
          order_id: string
          payment_id: string
          reason: string
          status?: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          initiated_by?: string
          mp_refund_id?: string
          order_id?: string
          payment_id?: string
          reason?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "refunds_initiated_by_fkey"
            columns: ["initiated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "refunds_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "refunds_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "refunds_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          admin_note: string | null
          booster_id: string | null
          content: string | null
          created_at: string
          customer_id: string
          id: string
          is_moderated: boolean
          is_public: boolean
          order_id: string
          rating: number
        }
        Insert: {
          admin_note?: string | null
          booster_id?: string | null
          content?: string | null
          created_at?: string
          customer_id: string
          id?: string
          is_moderated?: boolean
          is_public?: boolean
          order_id: string
          rating: number
        }
        Update: {
          admin_note?: string | null
          booster_id?: string | null
          content?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          is_moderated?: boolean
          is_public?: boolean
          order_id?: string
          rating?: number
        }
        Relationships: [
          {
            foreignKeyName: "reviews_booster_id_fkey"
            columns: ["booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "available_boost_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      riot_league_cutoffs: {
        Row: {
          cutoff_lp: number
          fetched_at: string
          queue: Database["public"]["Enums"]["queue_type"]
          tier: string
        }
        Insert: {
          cutoff_lp: number
          fetched_at?: string
          queue: Database["public"]["Enums"]["queue_type"]
          tier: string
        }
        Update: {
          cutoff_lp?: number
          fetched_at?: string
          queue?: Database["public"]["Enums"]["queue_type"]
          tier?: string
        }
        Relationships: []
      }
      service_extras: {
        Row: {
          code: string | null
          description: string
          flow: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          price_modifier: number
          price_modifier_pct: number
          service_id: string | null
          sort_order: number
        }
        Insert: {
          code?: string | null
          description: string
          flow?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          price_modifier?: number
          price_modifier_pct?: number
          service_id?: string | null
          sort_order?: number
        }
        Update: {
          code?: string | null
          description?: string
          flow?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price_modifier?: number
          price_modifier_pct?: number
          service_id?: string | null
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "service_extras_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          description: string | null
          game_id: string
          id: string
          is_active: boolean
          name: string
          short_description: string | null
          sort_order: number
          type: Database["public"]["Enums"]["service_type"]
        }
        Insert: {
          description?: string | null
          game_id: string
          id?: string
          is_active?: boolean
          name: string
          short_description?: string | null
          sort_order?: number
          type: Database["public"]["Enums"]["service_type"]
        }
        Update: {
          description?: string | null
          game_id?: string
          id?: string
          is_active?: boolean
          name?: string
          short_description?: string | null
          sort_order?: number
          type?: Database["public"]["Enums"]["service_type"]
        }
        Relationships: [
          {
            foreignKeyName: "services_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      available_boost_orders: {
        Row: {
          avg_pdl_gain: number | null
          avg_pdl_loss: number | null
          boost_mode: string | null
          created_at: string | null
          current_pdl: number | null
          current_rank: Json | null
          estimated_hours: number | null
          exclusive_until: string | null
          extras: Json | null
          game_id: string | null
          id: string | null
          losses_played: number | null
          pdl_bracket: string | null
          preferred_booster_id: string | null
          pricing_version: string | null
          queue_type: Database["public"]["Enums"]["queue_type"] | null
          server: string | null
          service_id: string | null
          sessions_purchased: number | null
          status: Database["public"]["Enums"]["order_status"] | null
          target_rank: Json | null
          total_price: number | null
          updated_at: string | null
          win_package: number | null
          wins_played: number | null
          wins_purchased: number | null
        }
        Insert: {
          avg_pdl_gain?: number | null
          avg_pdl_loss?: number | null
          boost_mode?: string | null
          created_at?: string | null
          current_pdl?: number | null
          current_rank?: Json | null
          estimated_hours?: number | null
          exclusive_until?: string | null
          extras?: Json | null
          game_id?: string | null
          id?: string | null
          losses_played?: number | null
          pdl_bracket?: string | null
          preferred_booster_id?: string | null
          pricing_version?: string | null
          queue_type?: Database["public"]["Enums"]["queue_type"] | null
          server?: string | null
          service_id?: string | null
          sessions_purchased?: number | null
          status?: Database["public"]["Enums"]["order_status"] | null
          target_rank?: Json | null
          total_price?: number | null
          updated_at?: string | null
          win_package?: number | null
          wins_played?: number | null
          wins_purchased?: number | null
        }
        Update: {
          avg_pdl_gain?: number | null
          avg_pdl_loss?: number | null
          boost_mode?: string | null
          created_at?: string | null
          current_pdl?: number | null
          current_rank?: Json | null
          estimated_hours?: number | null
          exclusive_until?: string | null
          extras?: Json | null
          game_id?: string | null
          id?: string | null
          losses_played?: number | null
          pdl_bracket?: string | null
          preferred_booster_id?: string | null
          pricing_version?: string | null
          queue_type?: Database["public"]["Enums"]["queue_type"] | null
          server?: string | null
          service_id?: string | null
          sessions_purchased?: number | null
          status?: Database["public"]["Enums"]["order_status"] | null
          target_rank?: Json | null
          total_price?: number | null
          updated_at?: string | null
          win_package?: number | null
          wins_played?: number | null
          wins_purchased?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "orders_preferred_booster_id_fkey"
            columns: ["preferred_booster_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      public_booster_profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          current_rank: Json | null
          display_name: string | null
          games: string[] | null
          id: string | null
          is_top3: boolean | null
          lanes: string[] | null
          last_active_at: string | null
          peak_rank: Json | null
          rating: number | null
          rating_count: number | null
          specialties: string[] | null
          total_completed: number | null
          updated_at: string | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "booster_profiles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      accept_boost_order: {
        Args: { p_booster_user_id: string; p_order_id: string }
        Returns: Json
      }
      admin_dashboard_stats: { Args: never; Returns: Json }
      admin_drop_order: {
        Args: { p_order_id: string; p_reason: string }
        Returns: Json
      }
      admin_mark_payout_paid: {
        Args: { p_proof_url: string; p_request_id: string }
        Returns: Json
      }
      admin_override_order_status: {
        Args: { p_new_status: string; p_order_id: string; p_reason?: string }
        Returns: Json
      }
      admin_release_duo_account: {
        Args: { p_account_id: string }
        Returns: Json
      }
      admin_resolve_order_support: {
        Args: { p_escalation_id: string }
        Returns: Json
      }
      admin_review_payout_request: {
        Args: { p_new_status: string; p_note?: string; p_request_id: string }
        Returns: Json
      }
      admin_set_order_chat_lock: {
        Args: { p_locked: boolean; p_order_id: string }
        Returns: Json
      }
      approve_booster: {
        Args: { p_booster_id: string; p_new_status: string }
        Returns: Json
      }
      booster_active_slot_counts: {
        Args: { p_booster_user_id: string }
        Returns: {
          duo_count: number
          solo_count: number
          total_count: number
        }[]
      }
      booster_available_balance: {
        Args: { p_booster_id: string }
        Returns: number
      }
      booster_has_active_exclusive_slot: {
        Args: { p_booster_user_id: string }
        Returns: boolean
      }
      booster_heartbeat: { Args: never; Returns: undefined }
      booster_payout_summary: {
        Args: { p_booster_user_id: string }
        Returns: Json
      }
      booster_payout_totals: { Args: { p_booster_id: string }; Returns: Json }
      can_booster_accept_order: {
        Args: { p_boost_mode: string; p_booster_user_id: string }
        Returns: Json
      }
      cancel_payout_request: { Args: { p_request_id: string }; Returns: Json }
      check_own_write_rate_limit: {
        Args: { p_limit: number; p_scope: string; p_window_seconds: number }
        Returns: boolean
      }
      complete_verified_order: {
        Args: {
          p_fetched_division: string
          p_fetched_tier: string
          p_order_id: string
          p_requested_by: string
        }
        Returns: Json
      }
      confirm_order_completion: { Args: { p_order_id: string }; Returns: Json }
      consume_edge_rate_limit: {
        Args: {
          p_limit: number
          p_scope: string
          p_subject: string
          p_window_seconds: number
        }
        Returns: Json
      }
      current_user_role: {
        Args: never
        Returns: Database["public"]["Enums"]["user_role"]
      }
      delete_duo_account: { Args: { p_account_id: string }; Returns: Json }
      dispute_order_completion: {
        Args: { p_order_id: string; p_reason: string }
        Returns: Json
      }
      duo_account_rank_is_valid: { Args: { p_rank: Json }; Returns: boolean }
      ensure_profile_exists: {
        Args: { p_display_name?: string }
        Returns: undefined
      }
      expire_stale_pix_orders: { Args: never; Returns: undefined }
      get_customer_order_state: { Args: { p_order_id?: string }; Returns: Json }
      get_duo_account_access_token: {
        Args: { p_account_id: string }
        Returns: Json
      }
      get_duo_account_credentials: {
        Args: { p_account_id: string }
        Returns: Json
      }
      get_order_chat: { Args: { p_order_id: string }; Returns: Json }
      get_order_credentials: { Args: { p_order_id: string }; Returns: Json }
      get_top_boosters: {
        Args: {
          p_limit?: number
          p_rank_bucket?: string
          p_service_type?: string
        }
        Returns: Json
      }
      is_admin: { Args: never; Returns: boolean }
      is_approved_booster:
        | { Args: never; Returns: boolean }
        | { Args: { p_booster_id: string }; Returns: boolean }
      list_duo_accounts: { Args: never; Returns: Json }
      mark_order_match_sync: { Args: { p_order_id: string }; Returns: Json }
      onboard_booster: {
        Args: {
          p_available_days?: string[]
          p_bio: string
          p_cpf?: string
          p_display_name: string
          p_full_name?: string
          p_hours_per_day_max?: number
          p_hours_per_day_min?: number
          p_opgg_link?: string
          p_peak_rank: Json
        }
        Returns: Json
      }
      order_requires_access_token: {
        Args: {
          p_boost_mode: string
          p_service_type: Database["public"]["Enums"]["service_type"]
        }
        Returns: boolean
      }
      payout_request_order_breakdown: {
        Args: { p_request_id: string }
        Returns: {
          amount_included: number
          booster_commission: number
          commission_rate: number
          gross_amount: number
          order_id: string
          service_type: Database["public"]["Enums"]["service_type"]
        }[]
      }
      process_mp_payment_event: {
        Args: {
          p_amount: number
          p_currency: string
          p_event_id: string
          p_mp_payment_id: string
          p_order_id: string
          p_provider_status: string
          p_refund_id?: string
        }
        Returns: Json
      }
      rank_bucket_of: { Args: { p_tier: string }; Returns: string }
      rank_step: {
        Args: { p_division: string; p_tier: string }
        Returns: number
      }
      record_order_match: {
        Args: {
          p_assists: number
          p_champion: string
          p_deaths: number
          p_duration_seconds: number
          p_external_match_id: string
          p_kills: number
          p_order_id: string
          p_played_at: string
          p_queue_id: number
          p_result: string
        }
        Returns: Json
      }
      record_pix_payment: {
        Args: {
          p_amount: number
          p_customer_id: string
          p_mp_payment_id: string
          p_order_id: string
        }
        Returns: Json
      }
      refresh_booster_performance_segments: {
        Args: { p_booster_id?: string }
        Returns: undefined
      }
      refresh_booster_rating: {
        Args: { p_booster_id: string }
        Returns: undefined
      }
      refresh_top3_boosters: { Args: never; Returns: undefined }
      release_duo_account_reservation: {
        Args: { p_order_id: string }
        Returns: Json
      }
      request_booster_role: { Args: never; Returns: Json }
      request_order_drop: {
        Args: { p_order_id: string; p_reason: string }
        Returns: Json
      }
      request_order_support: { Args: { p_order_id: string }; Returns: Json }
      request_payout: { Args: { p_amount: number }; Returns: Json }
      reserve_duo_account: {
        Args: { p_account_id: string; p_order_id: string }
        Returns: Json
      }
      resolve_drop_request: {
        Args: {
          p_admin_note?: string
          p_approve: boolean
          p_request_id: string
        }
        Returns: Json
      }
      resolve_duo_account_access_token: {
        Args: { p_access_token: string; p_booster_user_id: string }
        Returns: Json
      }
      resolve_order_access_token: {
        Args: { p_access_token: string; p_booster_user_id: string }
        Returns: Json
      }
      save_duo_account: {
        Args: {
          p_account_id: string
          p_division: string
          p_is_active: boolean
          p_label: string
          p_login?: string
          p_notes: string
          p_password?: string
          p_riot_id?: string
          p_tier: string
        }
        Returns: Json
      }
      send_order_message: {
        Args: { p_content: string; p_order_id: string }
        Returns: Json
      }
      set_duo_account_active: {
        Args: { p_account_id: string; p_is_active: boolean }
        Returns: Json
      }
      set_duo_account_credentials: {
        Args: { p_account_id: string; p_login: string; p_password: string }
        Returns: Json
      }
      set_order_credentials: {
        Args: { p_login: string; p_order_id: string; p_password: string }
        Returns: Json
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
      toggle_booster_top3: {
        Args: { p_booster_id: string; p_is_top3: boolean }
        Returns: Json
      }
      update_booster_professional_profile: {
        Args: {
          p_available_days: string[]
          p_bio: string
          p_display_name: string
          p_hours_per_day_max: number
          p_hours_per_day_min: number
          p_lanes: string[]
          p_opgg_link: string
          p_peak_tier: string
          p_specialties: string[]
        }
        Returns: Json
      }
      update_duo_account_rank: {
        Args: { p_account_id: string; p_division: string; p_tier: string }
        Returns: Json
      }
      update_my_username: { Args: { p_username: string }; Returns: Json }
      update_order_status: {
        Args: { p_new_status: string; p_order_id: string; p_reason?: string }
        Returns: Json
      }
    }
    Enums: {
      booster_status:
        | "pending"
        | "under_review"
        | "approved"
        | "suspended"
        | "rejected"
      ledger_entry_type:
        | "commission_credit"
        | "commission_adjustment"
        | "drop_penalty"
        | "refund_debit"
        | "manual_admin_adjustment"
        | "payout_reservation"
        | "payout_release"
        | "payout_paid"
      order_status:
        | "draft"
        | "awaiting_payment"
        | "paid"
        | "awaiting_assignment"
        | "assigned"
        | "in_progress"
        | "paused"
        | "drop_requested"
        | "awaiting_customer"
        | "completed"
        | "disputed"
        | "refunded"
        | "canceled"
      payment_status:
        | "pending"
        | "paid"
        | "failed"
        | "refunded"
        | "partially_refunded"
        | "disputed"
      payout_request_status:
        | "requested"
        | "under_review"
        | "approved"
        | "paid"
        | "rejected"
        | "canceled"
      payout_status: "pending" | "processing" | "paid" | "failed"
      queue_type: "solo_duo" | "flex"
      service_type:
        | "elo_boost"
        | "win_boost"
        | "coaching"
        | "placement_matches"
        | "md5"
      user_role: "customer" | "booster" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
  storage: {
    Tables: {
      buckets: {
        Row: {
          allowed_mime_types: string[] | null
          avif_autodetection: boolean | null
          created_at: string | null
          file_size_limit: number | null
          id: string
          name: string
          owner: string | null
          owner_id: string | null
          public: boolean | null
          type: Database["storage"]["Enums"]["buckettype"]
          updated_at: string | null
        }
        Insert: {
          allowed_mime_types?: string[] | null
          avif_autodetection?: boolean | null
          created_at?: string | null
          file_size_limit?: number | null
          id: string
          name: string
          owner?: string | null
          owner_id?: string | null
          public?: boolean | null
          type?: Database["storage"]["Enums"]["buckettype"]
          updated_at?: string | null
        }
        Update: {
          allowed_mime_types?: string[] | null
          avif_autodetection?: boolean | null
          created_at?: string | null
          file_size_limit?: number | null
          id?: string
          name?: string
          owner?: string | null
          owner_id?: string | null
          public?: boolean | null
          type?: Database["storage"]["Enums"]["buckettype"]
          updated_at?: string | null
        }
        Relationships: []
      }
      buckets_analytics: {
        Row: {
          created_at: string
          deleted_at: string | null
          format: string
          id: string
          name: string
          type: Database["storage"]["Enums"]["buckettype"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          deleted_at?: string | null
          format?: string
          id?: string
          name: string
          type?: Database["storage"]["Enums"]["buckettype"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          deleted_at?: string | null
          format?: string
          id?: string
          name?: string
          type?: Database["storage"]["Enums"]["buckettype"]
          updated_at?: string
        }
        Relationships: []
      }
      buckets_vectors: {
        Row: {
          created_at: string
          id: string
          type: Database["storage"]["Enums"]["buckettype"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          id: string
          type?: Database["storage"]["Enums"]["buckettype"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          type?: Database["storage"]["Enums"]["buckettype"]
          updated_at?: string
        }
        Relationships: []
      }
      migrations: {
        Row: {
          executed_at: string | null
          hash: string
          id: number
          name: string
        }
        Insert: {
          executed_at?: string | null
          hash: string
          id: number
          name: string
        }
        Update: {
          executed_at?: string | null
          hash?: string
          id?: number
          name?: string
        }
        Relationships: []
      }
      objects: {
        Row: {
          bucket_id: string | null
          created_at: string | null
          id: string
          last_accessed_at: string | null
          metadata: Json | null
          name: string | null
          owner: string | null
          owner_id: string | null
          path_tokens: string[] | null
          updated_at: string | null
          user_metadata: Json | null
          version: string | null
        }
        Insert: {
          bucket_id?: string | null
          created_at?: string | null
          id?: string
          last_accessed_at?: string | null
          metadata?: Json | null
          name?: string | null
          owner?: string | null
          owner_id?: string | null
          path_tokens?: string[] | null
          updated_at?: string | null
          user_metadata?: Json | null
          version?: string | null
        }
        Update: {
          bucket_id?: string | null
          created_at?: string | null
          id?: string
          last_accessed_at?: string | null
          metadata?: Json | null
          name?: string | null
          owner?: string | null
          owner_id?: string | null
          path_tokens?: string[] | null
          updated_at?: string | null
          user_metadata?: Json | null
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "objects_bucketId_fkey"
            columns: ["bucket_id"]
            isOneToOne: false
            referencedRelation: "buckets"
            referencedColumns: ["id"]
          },
        ]
      }
      s3_multipart_uploads: {
        Row: {
          bucket_id: string
          created_at: string
          id: string
          in_progress_size: number
          key: string
          metadata: Json | null
          owner_id: string | null
          upload_signature: string
          user_metadata: Json | null
          version: string
        }
        Insert: {
          bucket_id: string
          created_at?: string
          id: string
          in_progress_size?: number
          key: string
          metadata?: Json | null
          owner_id?: string | null
          upload_signature: string
          user_metadata?: Json | null
          version: string
        }
        Update: {
          bucket_id?: string
          created_at?: string
          id?: string
          in_progress_size?: number
          key?: string
          metadata?: Json | null
          owner_id?: string | null
          upload_signature?: string
          user_metadata?: Json | null
          version?: string
        }
        Relationships: [
          {
            foreignKeyName: "s3_multipart_uploads_bucket_id_fkey"
            columns: ["bucket_id"]
            isOneToOne: false
            referencedRelation: "buckets"
            referencedColumns: ["id"]
          },
        ]
      }
      s3_multipart_uploads_parts: {
        Row: {
          bucket_id: string
          created_at: string
          etag: string
          id: string
          key: string
          owner_id: string | null
          part_number: number
          size: number
          upload_id: string
          version: string
        }
        Insert: {
          bucket_id: string
          created_at?: string
          etag: string
          id?: string
          key: string
          owner_id?: string | null
          part_number: number
          size?: number
          upload_id: string
          version: string
        }
        Update: {
          bucket_id?: string
          created_at?: string
          etag?: string
          id?: string
          key?: string
          owner_id?: string | null
          part_number?: number
          size?: number
          upload_id?: string
          version?: string
        }
        Relationships: [
          {
            foreignKeyName: "s3_multipart_uploads_parts_bucket_id_fkey"
            columns: ["bucket_id"]
            isOneToOne: false
            referencedRelation: "buckets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "s3_multipart_uploads_parts_upload_id_fkey"
            columns: ["upload_id"]
            isOneToOne: false
            referencedRelation: "s3_multipart_uploads"
            referencedColumns: ["id"]
          },
        ]
      }
      vector_indexes: {
        Row: {
          bucket_id: string
          created_at: string
          data_type: string
          dimension: number
          distance_metric: string
          id: string
          metadata_configuration: Json | null
          name: string
          updated_at: string
        }
        Insert: {
          bucket_id: string
          created_at?: string
          data_type: string
          dimension: number
          distance_metric: string
          id?: string
          metadata_configuration?: Json | null
          name: string
          updated_at?: string
        }
        Update: {
          bucket_id?: string
          created_at?: string
          data_type?: string
          dimension?: number
          distance_metric?: string
          id?: string
          metadata_configuration?: Json | null
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vector_indexes_bucket_id_fkey"
            columns: ["bucket_id"]
            isOneToOne: false
            referencedRelation: "buckets_vectors"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      allow_any_operation: {
        Args: { expected_operations: string[] }
        Returns: boolean
      }
      allow_only_operation: {
        Args: { expected_operation: string }
        Returns: boolean
      }
      can_insert_object: {
        Args: { bucketid: string; metadata: Json; name: string; owner: string }
        Returns: undefined
      }
      extension: { Args: { name: string }; Returns: string }
      filename: { Args: { name: string }; Returns: string }
      foldername: { Args: { name: string }; Returns: string[] }
      get_common_prefix: {
        Args: { p_delimiter: string; p_key: string; p_prefix: string }
        Returns: string
      }
      get_size_by_bucket: {
        Args: never
        Returns: {
          bucket_id: string
          size: number
        }[]
      }
      list_multipart_uploads_with_delimiter: {
        Args: {
          bucket_id: string
          delimiter_param: string
          max_keys?: number
          next_key_token?: string
          next_upload_token?: string
          prefix_param: string
        }
        Returns: {
          created_at: string
          id: string
          key: string
        }[]
      }
      list_objects_with_delimiter: {
        Args: {
          _bucket_id: string
          delimiter_param: string
          max_keys?: number
          next_token?: string
          prefix_param: string
          sort_order?: string
          start_after?: string
        }
        Returns: {
          created_at: string
          id: string
          last_accessed_at: string
          metadata: Json
          name: string
          updated_at: string
        }[]
      }
      operation: { Args: never; Returns: string }
      search: {
        Args: {
          bucketname: string
          levels?: number
          limits?: number
          offsets?: number
          prefix: string
          search?: string
          sortcolumn?: string
          sortorder?: string
        }
        Returns: {
          created_at: string
          id: string
          last_accessed_at: string
          metadata: Json
          name: string
          updated_at: string
        }[]
      }
      search_by_timestamp: {
        Args: {
          p_bucket_id: string
          p_level: number
          p_limit: number
          p_prefix: string
          p_sort_column: string
          p_sort_column_after: string
          p_sort_order: string
          p_start_after: string
        }
        Returns: {
          created_at: string
          id: string
          key: string
          last_accessed_at: string
          metadata: Json
          name: string
          updated_at: string
        }[]
      }
      search_v2: {
        Args: {
          bucket_name: string
          levels?: number
          limits?: number
          prefix: string
          sort_column?: string
          sort_column_after?: string
          sort_order?: string
          start_after?: string
        }
        Returns: {
          created_at: string
          id: string
          key: string
          last_accessed_at: string
          metadata: Json
          name: string
          updated_at: string
        }[]
      }
    }
    Enums: {
      buckettype: "STANDARD" | "ANALYTICS" | "VECTOR"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  graphql_public: {
    Enums: {},
  },
  public: {
    Enums: {
      booster_status: [
        "pending",
        "under_review",
        "approved",
        "suspended",
        "rejected",
      ],
      ledger_entry_type: [
        "commission_credit",
        "commission_adjustment",
        "drop_penalty",
        "refund_debit",
        "manual_admin_adjustment",
        "payout_reservation",
        "payout_release",
        "payout_paid",
      ],
      order_status: [
        "draft",
        "awaiting_payment",
        "paid",
        "awaiting_assignment",
        "assigned",
        "in_progress",
        "paused",
        "drop_requested",
        "awaiting_customer",
        "completed",
        "disputed",
        "refunded",
        "canceled",
      ],
      payment_status: [
        "pending",
        "paid",
        "failed",
        "refunded",
        "partially_refunded",
        "disputed",
      ],
      payout_request_status: [
        "requested",
        "under_review",
        "approved",
        "paid",
        "rejected",
        "canceled",
      ],
      payout_status: ["pending", "processing", "paid", "failed"],
      queue_type: ["solo_duo", "flex"],
      service_type: [
        "elo_boost",
        "win_boost",
        "coaching",
        "placement_matches",
        "md5",
      ],
      user_role: ["customer", "booster", "admin"],
    },
  },
  storage: {
    Enums: {
      buckettype: ["STANDARD", "ANALYTICS", "VECTOR"],
    },
  },
} as const
