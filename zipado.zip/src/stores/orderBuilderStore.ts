import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { getBoostFlow, isMasterPlusCurrentTier, type BoostFlow, type BoostMode as BoostFlowMode } from '@/lib/boostDomain'
import type { GameSlug, ServiceType, QueueType, BoostMode, Rank } from '@/types'

export type OrderBuilderStep = 'service' | 'configure' | 'extras' | 'review' | 'payment'

interface OrderBuilderState {
  step: OrderBuilderStep
  steps: OrderBuilderStep[]

  // Selections
  gameSlug: GameSlug | null
  gameId: string | null
  serviceType: ServiceType | null
  serviceId: string | null
  currentRank: Rank | null
  targetRank: Rank | null
  queueType: QueueType
  boostMode: BoostMode
  server: string
  winsPurchased: number | null
  sessionsPurchased: number | null
  customerNotes: string
  // Ids (service_extras.id) dos addons selecionados — um Set, não um array de
  // clique: a ORDEM de exibição nunca vem daqui, sempre do catálogo (que já
  // chega ordenado por sort_order). Ver shared/boostDomain.ts::sortAddonsBySortOrder.
  selectedExtraIds: Set<string>
  winPackage: number | null   // 1, 3 or 5 extra wins; null = none

  // Pedido direto: booster escolhido no perfil público (via ?booster= na URL
  // de entrada). Só exibição/roteamento — a validação real acontece no
  // servidor ao criar o pedido.
  preferredBoosterId: string | null
  preferredBoosterName: string | null

  // Riot ID (nome#tag) — usado depois pra verificar automaticamente se o
  // rank alvo foi atingido antes de concluir o pedido.
  riotId: string

  // Verdadeiro enquanto uma consulta à Riot (rank atual / elegibilidade MD5)
  // está em andamento — movido de useState local em StepConfigure.tsx para
  // o store pra que OrderBuilder.tsx possa bloquear o avanço de step
  // enquanto a consulta não termina (ver isStepComplete).
  riotLookupLoading: boolean

  // Verdadeiro depois que o usuário tenta avançar de step com campos
  // obrigatórios faltando/inválidos — liga os hints de erro inline em
  // StepConfigure.tsx (FormField error=...) sem exibi-los antes da primeira
  // tentativa.
  stepAttempted: boolean

  // Verdadeiro assim que uma consulta Riot bem-sucedida preenche
  // rank/LP/PDL automaticamente — usado para travar esses campos até o
  // usuário clicar em "Editar" (setRiotAutoFilled(false)) ou alterar o
  // Riot ID manualmente.
  riotAutoFilled: boolean

  // Verdadeiro após uma verificação de conta bem-sucedida na fila atual —
  // porta de entrada do resto do formulário (eloboost/vitórias só liberam
  // ranks/extras depois disso). Reseta ao mudar Riot ID, fila ou serviço,
  // forçando nova verificação (a Riot é consultada por fila).
  riotVerified: boolean

  // Verdadeiro quando a conta consultada JÁ tem rank na fila atual — o toggle
  // de MD5 fica desabilitado (anti-fraude). O backend também rejeita, isto só
  // impede a tentativa no cliente. Reseta junto com riotVerified.
  md5Blocked: boolean

  // MD5: garantia de win rate nas partidas de posicionamento — toggle dentro
  // do fluxo "Vitórias" (win_boost), não um serviço separado na tela, mas
  // muda serviceType para 'md5' internamente (ver StepConfigure.tsx).
  isMd5: boolean
  md5MatchesRemaining: number | null
  md5MatchesRemainingCeiling: number | null

  // Pacote de coach escolhido (booster_services) — preço vem sempre daqui,
  // nunca editável pelo cliente. Selecionar um pacote também vincula o
  // pedido ao booster dono dele via setPreferredBooster.
  selectedCoachPackage: { id: string; title: string; price: number; tempo: string | null } | null

  // LP (PDL) — fluxo padrão (Solo/Duo, Iron–Diamond)
  currentLp: number
  avgLpGain: number
  avgLpLoss: number

  // PDL — fluxo Master+ (rank atual Master/Grão-Mestre). Não existe PDL alvo:
  // o preço vem da tabela comercial por faixa de PDL atual + progressão.
  currentPdl: number
  avgPdlGain: number
  avgPdlLoss: number

  // Computed
  basePrice: number
  extrasPrice: number
  estimatedHours: number | null
  // Percentual de modificador de PDL efetivamente aplicado ao basePrice
  // (-5, 0 ou +15) — null para Master+ e para qualquer serviceType que não
  // seja elo_boost padrão (Iron–Diamond). Espelha OrderPriceResult.pdlModifierPct.
  pdlModifierPct: number | null

  // Actions
  setStep: (step: OrderBuilderStep) => void
  nextStep: () => void
  prevStep: () => void
  setGame: (slug: GameSlug, id: string) => void
  setService: (type: ServiceType, id: string) => void
  // Só troca o uuid do serviço (resolução slug→uuid feita em OrderBuilder),
  // SEM resetar winsPurchased/MD5 como setService faz — senão a resolução do
  // uuid apagaria as partidas restantes detectadas pela Riot logo após ativar
  // o MD5.
  setServiceId: (id: string) => void
  setCurrentRank: (rank: Rank) => void
  setTargetRank: (rank: Rank | null) => void
  setQueueType: (queue: QueueType) => void
  setBoostMode: (mode: BoostMode) => void
  setServer: (server: string) => void
  setWinsPurchased: (wins: number) => void
  setIsMd5: (isMd5: boolean) => void
  setMd5MatchesRemaining: (n: number) => void
  setMd5MatchesRemainingFromApi: (n: number) => void
  setSessionsPurchased: (sessions: number) => void
  setNotes: (notes: string) => void
  toggleExtra: (extraId: string) => void
  setWinPackage: (wins: number | null) => void
  setPreferredBooster: (id: string, name: string) => void
  setRiotId: (riotId: string) => void
  setRiotAutoFilled: (v: boolean) => void
  setRiotVerified: (v: boolean) => void
  setMd5Blocked: (v: boolean) => void
  // Limpa qualquer resultado de uma conta consultada antes (rank/LP/PDL/MD5 e
  // flags de verificação) — chamado no início de cada nova busca pra que os
  // dados da conta anterior nunca vazem pra conta nova.
  clearRiotLookup: () => void
  setRiotLookupLoading: (v: boolean) => void
  setStepAttempted: (v: boolean) => void
  setSelectedCoachPackage: (pkg: { id: string; title: string; price: number; tempo: string | null } | null) => void
  setCurrentLp: (lp: number) => void
  setAvgLpGain: (lp: number) => void
  setAvgLpLoss: (lp: number) => void
  setCurrentPdl: (pdl: number) => void
  setAvgPdlGain: (pdl: number) => void
  setAvgPdlLoss: (pdl: number) => void
  setBasePrice: (price: number) => void
  setExtrasPrice: (price: number) => void
  setEstimatedHours: (hours: number | null) => void
  setPdlModifierPct: (pct: number | null) => void
  reset: () => void
}

const INITIAL_STEPS: OrderBuilderStep[] = ['service', 'configure', 'extras', 'review', 'payment']

const initialState = {
  step: 'service' as OrderBuilderStep,
  steps: INITIAL_STEPS,
  gameSlug: 'lol' as GameSlug,
  gameId: 'lol',
  serviceType: null,
  serviceId: null,
  currentRank: null,
  targetRank: null,
  queueType: 'solo_duo' as QueueType,
  boostMode: 'solo' as BoostMode,
  server: 'BR',
  winsPurchased: null,
  sessionsPurchased: null,
  customerNotes: '',
  isMd5: false,
  md5MatchesRemaining: null as number | null,
  md5MatchesRemainingCeiling: null as number | null,
  selectedExtraIds: new Set<string>(),
  winPackage: null,
  preferredBoosterId: null,
  preferredBoosterName: null,
  riotId: '',
  riotAutoFilled: false,
  riotVerified: false,
  md5Blocked: false,
  riotLookupLoading: false,
  stepAttempted: false,
  selectedCoachPackage: null,
  currentLp: 0,
  avgLpGain: 20,
  avgLpLoss: 15,
  currentPdl: 0,
  avgPdlGain: 30,
  avgPdlLoss: 30,
  basePrice: 0,
  extrasPrice: 0,
  estimatedHours: null,
  pdlModifierPct: null as number | null,
}

// Estado "sem consulta Riot": tudo que foi derivado de uma conta consultada
// (rank atual/última temporada, LP/PDL, detecção de MD5) mais as flags de
// verificação. Reaproveitado por clearRiotLookup e setQueueType — trocar de
// fila invalida a verificação porque a Riot é consultada por fila.
const CLEARED_LOOKUP_STATE = {
  currentRank: null,
  targetRank: null,
  currentLp: 0,
  avgLpGain: 20,
  avgLpLoss: 15,
  currentPdl: 0,
  avgPdlGain: 30,
  avgPdlLoss: 30,
  riotAutoFilled: false,
  riotVerified: false,
  md5Blocked: false,
  md5MatchesRemaining: null as number | null,
  md5MatchesRemainingCeiling: null as number | null,
}

// Fluxo do configurador (solo_standard/duo_standard/master_plus) para o
// (rank atual, modalidade) combinados — null se a combinação for inválida
// (ex.: rank ainda não escolhido).
function flowFor(rank: Rank | null, mode: BoostMode): BoostFlow | null {
  if (!rank) return null
  return getBoostFlow(rank.tier, mode as BoostFlowMode)
}

// Persistido em sessionStorage -- não localStorage -- pra sobreviver a um
// reload/troca de aba dentro da mesma sessão do navegador (o cenário real:
// o refetch automático do React Query em foco de janela nunca derruba
// estado de componente sozinho, mas o navegador pode descartar/recarregar
// uma aba em segundo plano por pressão de memória, o que zerava todo o
// progresso do configurador). Um pedido configurado não deve sobreviver ao
// fechamento da aba/navegador -- por isso sessionStorage, não localStorage.
export const useOrderBuilderStore = create<OrderBuilderState>()(
  persist(
    (set, get) => ({
  ...initialState,

  setStep: (step) => set({ step }),

  nextStep: () => {
    const { step, steps } = get()
    const idx = steps.indexOf(step)
    if (idx < steps.length - 1) set({ step: steps[idx + 1] })
  },

  prevStep: () => {
    const { step, steps } = get()
    const idx = steps.indexOf(step)
    if (idx > 0) set({ step: steps[idx - 1] })
  },

  setGame: (gameSlug, gameId) => set({ gameSlug, gameId }),
  setServiceId: (serviceId) => set({ serviceId }),
  setService: (serviceType, serviceId) => set({
    serviceType,
    serviceId,
    isMd5: serviceType === 'md5',
    winsPurchased: serviceType === 'win_boost' || serviceType === 'md5' ? 5 : null,
    md5MatchesRemaining: serviceType === 'md5' ? null : null,
    md5MatchesRemainingCeiling: serviceType === 'md5' ? null : null,
  }),

  setCurrentRank: (currentRank) => set((state) => {
    const forcedMasterPlus = isMasterPlusCurrentTier(currentRank.tier)
    const nextMode: BoostMode = forcedMasterPlus ? 'solo' : state.boostMode
    const prevFlow = flowFor(state.currentRank, state.boostMode)
    const nextFlow = flowFor(currentRank, nextMode)
    const flowChanged = prevFlow !== nextFlow

    return {
      currentRank,
      boostMode: nextMode,
      // Rank alvo depende do rank atual (progressão válida muda) — sempre
      // limpo ao trocar o rank atual, o usuário escolhe de novo.
      targetRank: null,
      selectedExtraIds: flowChanged ? new Set<string>() : state.selectedExtraIds,
      winPackage: flowChanged ? null : state.winPackage,
      currentLp: forcedMasterPlus ? 0 : state.currentLp,
      currentPdl: forcedMasterPlus ? state.currentPdl : 0,
    }
  }),

  setTargetRank: (targetRank) => set({ targetRank }),
  // Trocar de fila invalida a consulta anterior (rank e elegibilidade de MD5
  // são por fila) — limpa o resultado e trava o form até nova verificação.
  setQueueType: (queueType) => set({ ...CLEARED_LOOKUP_STATE, queueType }),

  setBoostMode: (boostMode) => set((state) => {
    // Duo nunca é aceito com rank atual Master+ — defesa em profundidade,
    // a UI não deve nem oferecer essa opção nesse caso.
    if (boostMode === 'duo' && state.currentRank && isMasterPlusCurrentTier(state.currentRank.tier)) {
      return {}
    }
    const prevFlow = flowFor(state.currentRank, state.boostMode)
    const nextFlow = flowFor(state.currentRank, boostMode)
    const flowChanged = prevFlow !== nextFlow

    return {
      boostMode,
      // Addons são exclusivos por fluxo (Solo ≠ Duo ≠ Master+) — trocar a
      // modalidade remove completamente os addons incompatíveis do estado,
      // não só da tela.
      selectedExtraIds: flowChanged ? new Set<string>() : state.selectedExtraIds,
    }
  }),

  setServer: (server) => set({ server }),
  setWinsPurchased: (winsPurchased) => set((state) => {
    const maxWins = state.isMd5 && state.md5MatchesRemaining != null
      ? Math.max(1, state.md5MatchesRemaining)
      : 5
    return { winsPurchased: Math.max(1, Math.min(winsPurchased, maxWins)) }
  }),
  setIsMd5: (isMd5) => set((state) => {
    // Toggling MD5 swaps the underlying service_type — resolved to a real
    // catalog uuid the same way StepService does (setService(slug, slug)
    // placeholder, OrderBuilderPage's catalog-service query resolves the uuid).
    const serviceType = isMd5 ? 'md5' : 'win_boost'
    return {
      isMd5,
      serviceType,
      serviceId: serviceType,
      winsPurchased: isMd5 && state.winsPurchased && state.winsPurchased > 5 ? 5 : state.winsPurchased,
      md5MatchesRemaining: isMd5 ? state.md5MatchesRemaining : null,
      md5MatchesRemainingCeiling: isMd5 ? state.md5MatchesRemainingCeiling : null,
    }
  }),
  setMd5MatchesRemaining: (md5MatchesRemaining) => set((state) => {
    const ceiling = state.md5MatchesRemainingCeiling ?? 5
    const next = Math.max(0, Math.min(md5MatchesRemaining, ceiling))
    return {
      md5MatchesRemaining: next,
      winsPurchased: state.isMd5 && state.winsPurchased != null
        ? Math.max(1, Math.min(state.winsPurchased, Math.max(1, next)))
        : state.winsPurchased,
    }
  }),
  setMd5MatchesRemainingFromApi: (n) => set(() => {
    const next = Math.max(0, Math.min(n, 5))
    return {
      md5MatchesRemaining: next,
      md5MatchesRemainingCeiling: next,
      winsPurchased: Math.max(1, next),
    }
  }),
  setSessionsPurchased: (sessionsPurchased) => set({ sessionsPurchased }),
  setNotes: (customerNotes) => set({ customerNotes }),

  toggleExtra: (extraId) =>
    set((state) => {
      const next = new Set(state.selectedExtraIds)
      if (next.has(extraId)) next.delete(extraId)
      else next.add(extraId)
      return { selectedExtraIds: next }
    }),

  setWinPackage: (winPackage) => set({ winPackage }),
  setPreferredBooster: (preferredBoosterId, preferredBoosterName) => set({ preferredBoosterId, preferredBoosterName }),
  // Editar o Riot ID invalida a verificação (form volta a travar) — mas NÃO
  // limpa o rank já preenchido a cada tecla; a limpeza completa acontece no
  // início da próxima busca (clearRiotLookup), pra não apagar dados enquanto
  // o usuário ainda está digitando.
  setRiotId: (riotId) => set({ riotId, riotAutoFilled: false, riotVerified: false, md5Blocked: false }),
  setRiotAutoFilled: (riotAutoFilled) => set({ riotAutoFilled }),
  setRiotVerified: (riotVerified) => set({ riotVerified }),
  setMd5Blocked: (md5Blocked) => set({ md5Blocked }),
  clearRiotLookup: () => set({ ...CLEARED_LOOKUP_STATE }),
  setRiotLookupLoading: (riotLookupLoading) => set({ riotLookupLoading }),
  setStepAttempted: (stepAttempted) => set({ stepAttempted }),
  setSelectedCoachPackage: (selectedCoachPackage) => set({ selectedCoachPackage }),

  setCurrentLp: (currentLp) => set({ currentLp }),
  setAvgLpGain: (avgLpGain) => set({ avgLpGain }),
  setAvgLpLoss: (avgLpLoss) => set({ avgLpLoss }),
  setCurrentPdl: (currentPdl) => set({ currentPdl }),
  setAvgPdlGain: (avgPdlGain) => set({ avgPdlGain }),
  setAvgPdlLoss: (avgPdlLoss) => set({ avgPdlLoss }),
  setBasePrice: (basePrice) => set({ basePrice }),
  setExtrasPrice: (extrasPrice) => set({ extrasPrice }),
  setEstimatedHours: (estimatedHours) => set({ estimatedHours }),
  setPdlModifierPct: (pdlModifierPct) => set({ pdlModifierPct }),

  reset: () => set({ ...initialState, selectedExtraIds: new Set<string>() }),
    }),
    {
      name: 'eloboost-order-builder',
      storage: createJSONStorage(() => sessionStorage, {
        // Set não é serializável em JSON puro -- codifica/decodifica
        // explicitamente (selectedExtraIds é o único Set no estado).
        replacer: (_key, value) => (value instanceof Set ? { __set: [...value] } : value),
        reviver: (_key, value) =>
          value && typeof value === 'object' && '__set' in (value as Record<string, unknown>)
            ? new Set((value as { __set: string[] }).__set)
            : value,
      }),
      // Só os dados do pedido em construção -- exclui riotLookupLoading (flag
      // transiente de "consulta em andamento") pra nunca restaurar travado
      // num loading que não existe mais depois de um reload.
      partialize: (state) => {
        const { riotLookupLoading: _riotLookupLoading, ...persisted } = state
        return persisted
      },
    },
  ),
)
