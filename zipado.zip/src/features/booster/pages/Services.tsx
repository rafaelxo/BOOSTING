import { Link } from 'react-router-dom'
import { Eye } from 'lucide-react'
import { Button } from '@/components/ui'
import { useAuthStore } from '@/stores/authStore'
import { BoosterProfessionalProfileForm } from '@/features/booster/components/BoosterProfessionalProfileForm'
import { BoosterServicesList } from '@/features/booster/components/BoosterServicesList'
import { useOwnBoosterProfileId } from '@/api/boosters'

export function BoosterServicesPage() {
  const { profile } = useAuthStore()

  // A rota pública usa booster_profiles.id (não o user_id) — busca só para o link de preview.
  const { data: boosterProfileId } = useOwnBoosterProfileId(profile?.id)

  if (!profile) return null

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-4">
        <h1 className="text-2xl font-bold text-ink">Serviços</h1>
        {boosterProfileId && (
          <Button asChild variant="outline" size="sm">
            <Link to={`/boosters/${boosterProfileId}`} target="_blank" rel="noopener noreferrer">
              <Eye className="h-4 w-4" />
              Visualizar como cliente
            </Link>
          </Button>
        )}
      </div>

      <BoosterProfessionalProfileForm userId={profile.id} />
      <BoosterServicesList userId={profile.id} />
    </div>
  )
}
